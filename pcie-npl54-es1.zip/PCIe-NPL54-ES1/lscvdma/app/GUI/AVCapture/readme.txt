1.install
sudo apt-get install libglfw3-dev
sudo apt-get install mesa-utils
sudo apt-get install libglew-dev 

sudo dpkg --configure -a
sudo apt-get install libasound2-dev

2.may just suport 16.04 or above
